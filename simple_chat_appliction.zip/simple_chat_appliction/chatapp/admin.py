from django.contrib import admin

from chatapp.models import Messages, Contact, ChatGroup

# Register your models here.


admin.site.register(Messages),
admin.site.register(Contact),
admin.site.register(ChatGroup),