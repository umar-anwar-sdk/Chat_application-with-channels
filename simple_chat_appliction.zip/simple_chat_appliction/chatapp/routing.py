from django.urls import path
from . import consumers

websocket_urlpatterns = [
    path('ws/chat/<int:user_id>/', consumers.ChatConsumer.as_asgi()), 
    path('ws/group/<int:group_id>/', consumers.GroupChatConsumer.as_asgi()),
    path('ws/video-call/', consumers.VideoCallConsumer.as_asgi()),
    path('ws/audio-call/', consumers.AudioCallConsumer.as_asgi()),     
]
