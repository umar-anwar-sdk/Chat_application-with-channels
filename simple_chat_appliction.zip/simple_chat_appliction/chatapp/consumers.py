import json
import logging
from channels.generic.websocket import AsyncWebsocketConsumer
from asgiref.sync import sync_to_async
from .models import ChatGroup, CustomUser, GroupMessage, Messages

logger = logging.getLogger(__name__)

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user_id = self.scope['url_route']['kwargs']['user_id']
        self.chat_room = f"user_chat_{self.user_id}"
        
        await self.channel_layer.group_add(self.chat_room, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.chat_room, self.channel_name)

    async def receive(self, text_data):
        try:
            data = json.loads(text_data)
            message = data.get('message')
            image = data.get('image')  
            video = data.get('video') 
            voice_message_url = data.get('voice_message_url')  

            if not message and not image and not video and not voice_message_url:
                return 
            sender_id = self.scope['user'].id
            receiver_id = self.user_id
            await self.save_message(sender_id, receiver_id, message, image, video, voice_message_url)

            await self.channel_layer.group_send(
                self.chat_room,
                {
                    'type': 'chat_message',
                    'message': message,
                    'image': image,
                    'video': video,
                    'voice_message_url': voice_message_url,
                    'sender_id': sender_id,
                    'sender_username': self.scope['user'].username,
                }
            )

        except Exception as e:
            logger.error(f"Error receiving message: {e}")

    async def chat_message(self, event):
        """Send the message to WebSocket"""
        message = event.get('message')
        image = event.get('image')
        video = event.get('video')
        voice_message_url = event.get('voice_message_url')
        sender_id = event['sender_id']
        sender_username = event['sender_username']

        await self.send(text_data=json.dumps({
            'sender_username': sender_username,
            'message': message,
            'image': image,
            'video': video,
            'voice_message_url': voice_message_url,
            'sender_id': sender_id,
        }))

    @sync_to_async
    def save_message(self, sender_id, receiver_id, message, image, video, voice_message_url):
        """Save the message to the database, including attachments"""
        try:
            sender = CustomUser.objects.get(id=sender_id)
            receiver = CustomUser.objects.get(id=receiver_id)
        
            return Messages.objects.create(
                sender=sender,
                receiver=receiver,
                content=message,
                image=image,
                video=video,
                voice_message_url=voice_message_url
            )

        except CustomUser.DoesNotExist:
            logger.error(f"User with ID {sender_id} or {receiver_id} does not exist.")
            return None

# Group Chat Consumer
class GroupChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.group_id = self.scope['url_route']['kwargs']['group_id']
        self.group_room = f"group_chat_{self.group_id}"

        await self.channel_layer.group_add(self.group_room, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.group_room, self.channel_name)

    async def receive(self, text_data):
        data = json.loads(text_data)
        message = data.get('message')
        image = data.get('image')
        video = data.get('video')
        audio = data.get('audio')

        if message or image or video or audio:
            sender_id = self.scope['user'].id
            group_id = self.group_id

            await self.save_group_message(sender_id, group_id, message, image, video, audio)
  
            sender = await sync_to_async(CustomUser.objects.get)(id=sender_id)

            await self.channel_layer.group_send(
                self.group_room,
                {
                    'type': 'group_chat_message',
                    'message': message,
                    'image': image,
                    'video': video,
                    'audio': audio,
                    'sender_id': sender_id,
                    'sender_username': sender.username, 
                }
            )

    async def group_chat_message(self, event):
        message = event.get('message')
        image = event.get('image')
        video = event.get('video')
        audio = event.get('audio')
        sender_id = event['sender_id']
        sender_username = event['sender_username']  

        await self.send(text_data=json.dumps({
            'message': message,
            'image': image,
            'video': video,
            'audio': audio,
            'sender_id': sender_id,
            'sender_username': sender_username, 
        }))

    @sync_to_async
    def save_group_message(self, sender_id, group_id, message, image, video, audio):
        try:
            sender = CustomUser.objects.get(id=sender_id)
            group = ChatGroup.objects.get(id=group_id)
            return GroupMessage.objects.create(
                sender=sender,
                group=group,
                content=message,
                image=image,
                video=video,
                audio=audio
            )
        except CustomUser.DoesNotExist as e:
            logger.error(f"User does not exist: {e}")
            return None
        except ChatGroup.DoesNotExist as e:
            logger.error(f"ChatGroup does not exist: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error while saving group message: {e}")
            return None
        


# video calling
import json
from channels.generic.websocket import WebsocketConsumer

class VideoCallConsumer(WebsocketConsumer):
    def connect(self):
        self.accept()

    def disconnect(self, close_code):
        pass

    def receive(self, text_data):
        data = json.loads(text_data)

        if data['type'] == 'offer':
            self.send(json.dumps({'type': 'offer', 'offer': data['offer']}))
        elif data['type'] == 'answer':
            self.send(json.dumps({'type': 'answer', 'answer': data['answer']}))
        elif data['type'] == 'candidate':
            self.send(json.dumps({'type': 'candidate', 'candidate': data['candidate']}))
# Audio Call 


import json
from channels.generic.websocket import WebsocketConsumer

class AudioCallConsumer(WebsocketConsumer):
    def connect(self):
        self.accept()

    def disconnect(self, close_code):
        pass

    def receive(self, text_data):
        data = json.loads(text_data)

        if data['type'] == 'offer':
            self.send(json.dumps({'type': 'offer', 'offer': data['offer']}))
        elif data['type'] == 'answer':
            self.send(json.dumps({'type': 'answer', 'answer': data['answer']}))
        elif data['type'] == 'candidate':
            self.send(json.dumps({'type': 'candidate', 'candidate': data['candidate']}))

