from datetime import timezone
import os
from scipy.io.wavfile import write
from django.http import JsonResponse, HttpResponse
from django.shortcuts import redirect, render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.core.files.storage import default_storage
from .models import ChatGroup, Contact, CustomUser, GroupMessage, Messages 
from django.conf import settings
from django.db.models import Q
from django.core.files.base import ContentFile



recording_thread = None
is_recording = False
frames = []

# Function to record sound
def sound():
    pass
#     global frames, is_recording
#     Chunk = 1024
#     Format = pyaudio.paInt16
#     Channels = 1
#     rate = 44100

#     p = pyaudio.PyAudio()
#     stream = p.open(format=Format, channels=Channels, rate=rate, input=True, frames_per_buffer=Chunk)

#     frames = []
#     is_recording = True
#     while is_recording:
#         data = stream.read(Chunk)
#         frames.append(data)

#     stream.stop_stream()
#     stream.close()
#     p.terminate()

# Start recording
def start_recording(request):
    pass
    # global recording_thread
    # if request.method == 'POST':
    #     recording_thread = threading.Thread(target=sound)
    #     recording_thread.start()
    #     return JsonResponse({'status': 'Recording started'})

def stop_recording(request):
    pass
    # global is_recording, frames, recording_thread

    # if request.method == 'POST':
    #     is_recording = False
    #     recording_thread.join()
    #     try:
    #         wf = wave.open('output.wav', 'wb')
    #         wf.setnchannels(1)
    #         wf.setsampwidth(pyaudio.PyAudio().get_sample_size(pyaudio.paInt16))
    #         wf.setframerate(44100)
    #         wf.writeframes(b''.join(frames))
    #         wf.close()
    #     except Exception as e:
    #         print(f"Error saving wave file: {e}")
    #         return JsonResponse({'status': 'Error in saving audio'}, status=500)
    #     try:
    #         voice_message = voice()
    #         with open('output.wav', 'rb') as f:
    #             voice_message.voice.save('recorded_audio.wav', ContentFile(f.read()))
    #         voice_message.save()
    #         voice_message_url = voice_message.voice.url
    #         return JsonResponse({'status': 'success', 'voice_message_url': voice_message_url})
    #     except Exception as e:
    #         print(f"Error handling the voice message: {e}")
    #         return JsonResponse({'status': 'Error in handling voice message'}, status=500)

    # return JsonResponse({'status': 'Error'}, status=400)

@login_required(login_url='login')
def user_list(request):
    try:
        all_users = CustomUser.objects.exclude(id=request.user.id)
        return render(request, 'chat_home.html', {'all_users': all_users})
    except Exception as e:
        messages.error(request, f"Error fetching user list: {e}")
        return render(request, 'chat_home.html', {'all_users': []})


# def convert_audio_to_text(audio_file):
#     recognizer = sr.Recognizer()
#     try:
#         with sr.AudioFile(audio_file) as source:
#             audio_data = recognizer.record(source)
#             audio_text = recognizer.recognize_google(audio_data, language='en-us')
#     except sr.UnknownValueError:
#         audio_text = "Could not understand audio"
#     except sr.RequestError as e:
#         audio_text = f"Error with speech recognition service; {e}"
#     return audio_text

@login_required(login_url='login')
def chat_user(request, user_id):
    receiver = get_object_or_404(CustomUser, id=user_id)

    if request.method == 'POST':
        content = request.POST.get('content', "")
        image = request.FILES.get('image')
        video = request.FILES.get('video')
        audio = request.FILES.get('audio')
        voice_message_url = request.POST.get('voice_message_url')  

        # audio_text = ""
        # if audio:
        #     audio_text = convert_audio_to_text(audio)

        message = Messages.objects.create(
            sender=request.user,
            receiver=receiver,
            content=content,
            image=image,
            video=video,
            # audio_text=audio_text,
            voice_message_url=voice_message_url  
        )

        return JsonResponse({
            'status': 'success',
            'message': {
                'content': message.content,
                'image': message.image.url if message.image else None,
                'video': message.video.url if message.video else None,
                # 'audio_text': message.audio_text,
                'voice_message_url': message.voice_message_url if message.voice_message_url else None,  
                'timestamp': message.timestamp.strftime('%H:%M')
            }
        })


    messages_list = Messages.objects.filter(
        Q(sender=request.user, receiver=receiver) |
        Q(sender=receiver, receiver=request.user)
    ).order_by('timestamp')

    return render(request, 'chat_user.html', {
        'receiver': receiver,
        'messages': messages_list,
    })
from django.http import JsonResponse
@login_required
def group_chat(request, group_id):
    group = get_object_or_404(ChatGroup, id=group_id)

    if request.method == 'POST':
        content = request.POST.get('content', '').strip()
        image = request.FILES.get('image')
        video = request.FILES.get('video')
        voice_message_url = request.POST.get('voice_message_url') 

        audio_text = ""

        
        if content or image or video : 
            message = GroupMessage.objects.create(
                group=group,
                sender=request.user,
                content=content,
                image=image,
                video=video,
                audio_text=audio_text,
                voice_message_url=voice_message_url,
            )

            response_data = {
                'status': 'success',
                'message': {
                    'content': message.content,
                    'image_url': message.image.url if message.image else '',
                    'video_url': message.video.url if message.video else '',
                    'audio_text': message.audio_text,
                    'voice_message_url': message.voice_message_url if message.voice_message_url else None, 
                    'timestamp': message.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                    'sender_username': message.sender.username,
                }
            }
        else:
            response_data = {
                'status': 'error',
                'message': 'No content to send.'
            }

        return JsonResponse(response_data)

    messages_list = group.messages.all().order_by('timestamp')

    return render(request, 'group_chat.html', {
        'group': group,
        'messages': messages_list
    })

@login_required
def view_messages(request):
    sent_messages = Messages.objects.filter(sender=request.user).order_by('-timestamp')
    received_messages = Messages.objects.filter(receiver=request.user).order_by('-timestamp')

    return render(request, 'view_messages.html', {
        'sent_messages': sent_messages,
        'received_messages': received_messages
    })

@login_required
def profile(request):
    user = get_object_or_404(CustomUser, id=request.user.id)
    return render(request, 'profile.html', {'user': user})

@login_required
def profile_update(request):
    if request.method == "POST":
        profile_pic = request.FILES.get('profile_pic')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        phone_number = request.POST.get('phone_number')
        password = request.POST.get('password')

        try:
            customuser = CustomUser.objects.get(id=request.user.id)
            customuser.first_name = first_name
            customuser.last_name = last_name
            customuser.phone_number = phone_number
            if password:
                customuser.set_password(password)
            if profile_pic:
                customuser.profile_pic = profile_pic
            customuser.save()
            messages.success(request, 'Your Profile Updated Successfully!')
            return redirect('profile')
        except CustomUser.DoesNotExist:
            messages.error(request, 'Failed to update your profile.')

    return render(request, 'profile.html')

@login_required
def save_contact(request):
    if request.method == 'POST':
        contact_user_id = request.POST.get('contact_user_id')
        contact_user = get_object_or_404(CustomUser, id=contact_user_id)

        if Contact.objects.filter(owner=request.user, contact_user=contact_user).exists():
            messages.info(request, 'Contact already saved.')
        else:
            Contact.objects.create(
                owner=request.user,
                contact_user=contact_user,
                phone_number=contact_user.phone_number
            )
            messages.success(request, 'Contact saved successfully!')

    return redirect('user_list')

@login_required
def contact_save(request):
    contacts = Contact.objects.filter(owner=request.user).select_related('contact_user')
    mutual_contacts = []

    for contact in contacts:
        other_user = contact.contact_user
        if Contact.objects.filter(owner=other_user, contact_user=request.user).exists():
            mutual_contacts.append(contact)

    return render(request, 'contact_list.html', {'contacts': mutual_contacts})

@login_required
def join_group(request, group_id):
    group = get_object_or_404(ChatGroup, id=group_id)
    if request.method == 'POST':
        if request.user not in group.members.all():
            group.members.add(request.user)
            messages.success(request, 'Joined the group successfully!')
        else:
            messages.info(request, 'You are already a member of this group.')
        return redirect('group_chat', group_id=group.id)

    return render(request, 'join_group.html', {'group': group})

@login_required
def remove_group(request, group_id):
    group = get_object_or_404(ChatGroup, id=group_id, admin=request.user)
    if request.method == 'POST':
        group.delete()
        messages.success(request, 'Group removed successfully!')
        return redirect('view_all_groups')

    return render(request, 'confirm_remove_group.html', {'group': group})

@login_required
def view_all_groups(request):
    contacts = Contact.objects.filter(owner=request.user)
    if contacts.exists():
        groups = ChatGroup.objects.all()
        return render(request, 'chat_home.html', {'groups': groups})
    else:
        messages.info(request, 'No groups available because you have not saved any contacts.')
        return render(request, 'chat_home.html', {'groups': []})

@login_required
def remove_contact(request, contact_user_id):
    contact = get_object_or_404(Contact, owner=request.user, contact_user_id=contact_user_id)
    if request.method == 'POST':
        contact.delete()
        messages.success(request, 'Contact removed successfully!')
        return redirect('contact_list')

    return render(request, 'confirm_remove_contact.html', {'contact': contact})

@login_required
def create_group(request):
    if request.method == 'POST':
        group_name = request.POST.get('name')
        phone_numbers = request.POST.get('phone_numbers')

        if group_name and phone_numbers:
            group = ChatGroup.objects.create(name=group_name, admin=request.user)
            group.members.add(request.user)
            phone_numbers_list = [phone.strip() for phone in phone_numbers.split(',')]
            for phone_number in phone_numbers_list:
                try:
                    contact = Contact.objects.get(owner=request.user, phone_number=phone_number)
                    group.members.add(contact.contact_user)
                except Contact.DoesNotExist:
                    messages.warning(request, f"Contact with phone number {phone_number} does not exist.")

            group.save()
            messages.success(request, 'Group created successfully and members added!')
            return redirect('group_chat', group_id=group.id)
        else:
            messages.error(request, 'Group name and phone numbers are required.')

    return render(request, 'create_group.html')

@login_required
def add_group_members(request, group_id):
    group = get_object_or_404(ChatGroup, id=group_id)

    if request.user != group.admin:
        messages.error(request, 'Only the admin can add members to this group.')
        return redirect('group_chat', group_id=group.id)

    contacts = Contact.objects.filter(owner=request.user)

    if request.method == 'POST':
        selected_contacts = request.POST.getlist('contacts')

        for contact_id in selected_contacts:
            try:
                contact = Contact.objects.get(id=contact_id)
                if contact.contact_user not in group.members.all():
                    group.members.add(contact.contact_user)
                    messages.success(request, f"Added {contact.contact_user} to the group.")
                else:
                    messages.info(request, f"{contact.contact_user} is already a member.")
            except Contact.DoesNotExist:
                messages.warning(request, 'One or more selected contacts no longer exist.')

        group.save()
        return redirect('group_chat', group_id=group.id)

    return render(request, 'add_group_members.html', {'group': group, 'contacts': contacts})

@login_required
def remove_group_members(request, group_id):
    group = get_object_or_404(ChatGroup, id=group_id)

    if request.user != group.admin:
        messages.error(request, 'Only the admin can remove members from this group.')
        return redirect('group_chat', group_id=group.id)

    members = group.members.exclude(id=request.user.id)

    if request.method == 'POST':
        selected_members = request.POST.getlist('members')

        for member_id in selected_members:
            try:
                member = CustomUser.objects.get(id=member_id)
                group.members.remove(member)
                messages.success(request, f"Removed {member.username} from the group.")
            except CustomUser.DoesNotExist:
                messages.warning(request, 'One or more selected members no longer exist.')

        group.save()
        return redirect('group_chat', group_id=group.id)

    return render(request, 'remove_group_members.html', {'group': group, 'members': members})





# audio Call

def audio_call(request):
    return render(request, 'audio_call.html')

def video_call(request):
    return render(request, 'video_call.html')