from django.urls import path

from chatapp.consumers import AudioCallConsumer
from . import views
from .views import add_group_members, audio_call, create_group, join_group, group_chat , remove_group_members, start_recording, stop_recording, video_call, view_all_groups

urlpatterns = [
    path('', views.user_list, name='user_list'),
    path('chat/<int:user_id>/', views.chat_user, name='chat_user'),
    path('messages/', views.view_messages, name='view_messages'),
    path('profile/', views.profile, name='profile'),
    path('profile/update/', views.profile_update, name='profile_update'),
    path('save-contact/', views.save_contact, name='save_contact'),
    path('contacts/', views.contact_save, name='contact_list'),
    path('view_all_groups/', view_all_groups, name='view_all_groups'),
    path('create-group/', create_group, name='create_group'),
    path('join-group/<int:group_id>/', join_group, name='join_group'),
    path('group-chat/<int:group_id>/', group_chat, name='group_chat'),
    path('remove_contact/<int:contact_user_id>/', views.remove_contact, name='remove_contact'),
    path('group/remove/<int:group_id>/', views.remove_group, name='remove_group'),
    path('add_group_members/<int:group_id>/', add_group_members, name='add_group_members'),
    path('remove_group_members/<int:group_id>/', remove_group_members, name='remove_group_members'),

    # Recording Urls
     path('start-recording/', start_recording, name='start-recording'),
    path('stop-recording/', stop_recording, name='stop-recording'),
    # Calling Urls
    path('audio_call/', audio_call, name= 'audio_call'),
    path('video_call', video_call, name='video_call')
]
