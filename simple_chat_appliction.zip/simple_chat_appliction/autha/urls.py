from django.urls import path
from autha.views import *
urlpatterns = [
    path('login/',LoginPage,name='login'),
    path('signup/',SignupPage,name='signup'), 
    path('logout/',LogoutPage,name='logout'),
]